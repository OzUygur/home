
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('contact.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert('Thank you for your message!');
        document.getElementById('contactForm').reset();
    })
    .catch(error => {
        alert('There was a problem with your submission. Please try again.');
    });
});

