<?php
session_start();
include 'track_visitor.php';

function getDbConnection() {
    $servername = "localhost";
    $username = "u468298250_ozuygur";
    $password = "Mehpi_numur_99";
    $dbname = "u468298250_ozuygur";

    $conn = new mysqli($servername, $username, $password, $dbname);
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Error reporting for better debugging
    return $conn;
}

function fetchContent($section) {
    $conn = getDbConnection();
    $sql = "SELECT $section FROM content WHERE id=1";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    $conn->close();
    return $result;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahmut Can Özuygur Portfolio</title>
    <link rel="icon" href="ozuygur.png" type="image/x-icon">
    <style>
   
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            justify-content: center;
            display: flex;
            min-height: 100vh;
            flex-direction: column;
            background-color: #f4f4f4;
            padding: 0px;
            box-sizing: border-box;
            text-align: justify;
            margin:0;
        }

        header {
            background-color: rgba(3, 180, 252, 0.7);
            color: white;
            text-align: center;
            
        }

        #navbar {
            background-color: #333;
            padding: 10px;
            color: white;
            text-align: center;
        }
        
        #navbar-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        #navbar-links li {
            display: inline;
            margin-right: 20px;
        }
        
        #navbar-links li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s ease; /* Smooth transition for color change */
        }
        
        /* Hover effect for navbar links */
        #navbar-links li a:hover {
            color: rgba(3, 180, 252, 0.7); /* Change the text color on hover */
            font-weight: bold; /* Make the text bold on hover */
        }


        .menu-toggle {
            display: none;
            background-color: #333;
            color: white;
            font-size: 20px;
            border: none;
            cursor: pointer;
            padding-left:15px;
        }

        #sidebar {
            position: fixed;
            top: 0;
            left: -250px;
            width: 250px;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            transition: left 0.3s ease;
            z-index: 1000;
            text-align:center;
            font-weight:bold;
        }

        #sidebar ul {
            list-style: none;
            padding: 0;
        }
        
        #sidebar ul li {
            margin: 15px 0;
        }
        
        #sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: block;
            transition: background-color 0.3s ease; /* Smooth transition for background color */
        }
        
        /* Hover effect */
        #sidebar ul li a:hover {
            background-color: rgba(3, 180, 252, 0.7); /* Change the background color on hover */
            font-weight: bold; /* Make the text bold */
        }


        #sidebar .close-btn {
            color: white;
            font-size: 30px;
            padding: 10px;
            cursor: pointer;
            background: none;
            border: none;
            position: absolute;
            top: 10px;
            right: 10px;
        }

        #sidebar.open {
            left: 0;
        }

        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }

            #navbar-links {
                display: none;
            }

            #sidebar {
                display: flex;
            }
        }

        section {
            padding: 2em;
            background-color: #fff;
            margin-bottom: 20px;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2em;
        }

        th, td {
            padding: 0.5em;
            border: 1px solid #ddd;
            text-align: left;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 0.5em 0 0.2em;
        }

        input, textarea {
            padding: 0.5em;
            margin-bottom: 1em;
        }

        textarea {
            min-height: 5cm;
        }

        button {
            background-color: rgba(3, 180, 252, 0.7);
            color: white;
            border: none;
            padding: 0.7em;
            cursor: pointer;
        }

        button:hover {
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-weight: bold;
        }

        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            text-align: center;
            padding: 2em 0;
        }

    </style>
</head>
<body>
    <header>
        <h1>Mahmut Can Özuygur</h1>
        <p>PhD in Physics | Data Scientist | Educator</p>
    </header>

    <nav id="navbar">
        <button class="menu-toggle" id="menu-toggle">&#9776;</button>
        <ul id="navbar-links">
            <li><a href="#about">About</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#experience">Experience</a></li>
            <li><a href="#contact">Contact</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
                <li><a href="dashboard.php">Dashboard</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <nav id="sidebar">
        <button class="close-btn" id="close-btn">&times;</button>
        <ul>
            <li><a href="#about">About</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#experience">Experience</a></li>
            <li><a href="#contact">Contact</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
                <li><a href="dashboard.php">Dashboard</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <main>
        <section id="about">
            <h2>About Me</h2>
            <?php
            $result = fetchContent('about');
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>" . $row["about"] . "</p>";
                }
            } else {
                echo "<p>Content not available.</p>";
            }
            ?>
        </section>

        <section id="skills">
            <h2>Skills</h2>
            <?php
            $result = fetchContent('skills');
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>" . str_replace(",", "", $row["skills"]) . "</p>";
                }
            } else {
                echo "<p>Content not available.</p>";
            }
            ?>
        </section>

        <section id="experience">
            <h2>Work Experiences</h2>
            <?php
            $result = fetchContent('experience');
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>" . str_replace(",", "", $row["experience"]) . "</p>";
                }
            } else {
                echo "<p>Content not available.</p>";
            }
            ?>
        </section>

        <section id="projects">
            <h2>Projects</h2>
            <?php
            $result = fetchContent('projects');
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>" . str_replace(",", "", $row["projects"]) . "</p>";
                }
            } else {
                echo "<p>Content not available.</p>";
            }
            ?>
        </section>

        <section id="contact">
            <h2>Contact</h2>
            <form id="contactForm" action="contact.php" method="POST">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea>
                <button type="submit">Submit</button>
            </form>
        </section>
    </main>

    <footer>
        <?php echo date("Y"); ?> &copy; Özuygur
    </footer>

    <script>
        document.getElementById('menu-toggle').addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });

        document.getElementById('close-btn').addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            sidebar.classList.remove('open');
        });
    </script>
</body>
</html>
