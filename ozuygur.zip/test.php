<?php
$servername = "localhost";
$username = "u468298250_ozuygur";
$password = "Mehpi_numur_99";
$dbname = "u468298250_ozuygur";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Query to fetch visitor statistics from database
$stats_sql = "SELECT COUNT(id) AS total_visits, COUNT(DISTINCT id) AS unique_visitors FROM visits";
$stats_result = $conn->query($stats_sql);

// Initialize variables to store statistics
$total_visits = 0;
$unique_visitors = 0;

// Check if there are any statistics
if ($stats_result->num_rows > 0) {
    // Fetch statistics and store them in variables
    $stats_row = $stats_result->fetch_assoc();
    $total_visits = $stats_row['total_visits'];
    $unique_visitors = $stats_row['unique_visitors'];
}


// Query to fetch inbox messages from database
$messages_sql = "SELECT name, email, message FROM contact_form";
$messages_result = $conn->query($messages_sql);

// Initialize array to store messages
$messages = [];

// Check if there are any messages
if ($messages_result->num_rows > 0) {
    // Fetch messages and store them in array
    while($row = $messages_result->fetch_assoc()) {
        $messages[] = $row['name'] . ' (' . $row['email'] . '): ' . $row['message'];
    }
} else {
    $messages[] = "No messages yet.";
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>Dashboard</h1>

    <h2>Visitor Statistics</h2>
    <p>Total Visits: <?php echo $total_visits; ?></p>
    <p>Unique Visitors: <?php echo $unique_visitors; ?></p>

    <h2>Inbox Messages</h2>
    <ul>
        <?php foreach ($messages as $message) : ?>
            <li><?php echo $message; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
