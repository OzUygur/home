<?php
$servername = "localhost";
$username = "u468298250_ozuygur";
$password = "Mehpi_numur_99";
$dbname = "u468298250_ozuygur";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize messages array
$messages = [];

// Fetch messages from contact form table
$sql = "SELECT name, email, message FROM contact_form";
$result = $conn->query($sql);

// Check if there are any results
if ($result) {
    // Fetch and format messages
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row['name'] . ' (' . $row['email'] . '): ' . $row['message'];
    }
} else {
    // If there are no results or an error occurred
    $messages[] = "No messages found";
}

// Close connection
$conn->close();

// Encode messages array into JSON and echo it
echo json_encode(['messages' => $messages]);
?>
