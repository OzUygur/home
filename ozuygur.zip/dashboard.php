<?php
$servername = "localhost";
$username = "u468298250_ozuygur";
$password = "Mehpi_numur_99";
$dbname = "u468298250_ozuygur";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch existing content
$sql = "SELECT * FROM content WHERE id=1";
$result = $conn->query($sql);

$content = $result->fetch_assoc();

// Fetch visitor statistics
$stats_sql = "SELECT COUNT(id) AS total_visits, COUNT(DISTINCT ip_address) AS unique_visitors FROM visits";
$stats_result = $conn->query($stats_sql);

$total_visits = 0;
$unique_visitors = 0;

if ($stats_result->num_rows > 0) {
    $stats_row = $stats_result->fetch_assoc();
    $total_visits = $stats_row['total_visits'];
    $unique_visitors = $stats_row['unique_visitors'];
}

// Fetch inbox messages
$messages_sql = "SELECT name, email, message FROM contact_form ORDER BY id DESC LIMIT 3";
$messages_result = $conn->query($messages_sql);

$messages = [];
if ($messages_result->num_rows > 0) {
    while ($row = $messages_result->fetch_assoc()) {
        $messages[] = $row['name'] . ': ' . $row['email'] . ': ' . $row['message'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    
    <style>
        body {
            background-color: #f0f2f5;
        }
        
        .container {
            background-color: #ffffff;
            padding: 0px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .nav-tabs .nav-link {
            border-radius: 0;
            padding: 10px 7px;
            font-size: 0.8rem;
            font-weight:bold;
        }

        .nav-tabs .nav-link.active {
            background-color: rgba(3, 180, 252, 0.7);
            color: white;
            font-weight: bold;
        }

        .tab-content {
            padding: 20px;
            border: 1px solid #ddd;
            border-top: none;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-control {
            border-radius: 5px;
            border-color: #ced4da;
            padding: 12px;
        }

        .btn-primary {
            background-color: rgba(3, 180, 252, 0.7);
            border-color: rgba(3, 180, 252, 0.7);
            border-radius: 5px;
            padding: 12px 20px;
            font-size: 1rem;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            font-size: 1rem;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f1f1f1;
            font-weight: bold;
        }

        table tr:hover {
            background-color: #f9f9f9;
        }

        .card {
            margin-bottom: 20px;
        }
        
        .stat-box {
            background: rgba(3, 180, 252, 0.7);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-box h3 {
            font-size: 2rem;
        }

    </style>
</head>
<body>

<div class="container">
    <h1 class="mb-4 text-center">Admin Dashboard</h1>
    
<ul class="nav nav-tabs" id="myTab" role="tablist">
    
    <li class="nav-item" role="presentation">
        <a class="nav-link" href="index.php">
            <i class="fas fa-home"></i> Home
        </a>
    </li>
    
    <li class="nav-item" role="presentation">
        <a class="nav-link" id="editContent-tab" data-bs-toggle="tab" href="#editContent" role="tab" aria-controls="editContent" aria-selected="false">
            <i class="fas fa-edit"></i> Edit Content
        </a>
    </li>
    
    <li class="nav-item" role="presentation">
        <a class="nav-link" id="statistics-tab" data-bs-toggle="tab" href="#statistics" role="tab" aria-controls="statistics" aria-selected="false">
            <i class="fas fa-chart-line"></i> Statistics
        </a>
    </li>
    
    <li class="nav-item" role="presentation">
        <a class="nav-link" id="inbox-tab" data-bs-toggle="tab" href="#inbox" role="tab" aria-controls="inbox" aria-selected="false">
            <i class="fas fa-inbox"></i> Inbox
        </a>
    </li>
    
</ul>

    
    <div class="tab-content" id="myTabContent">
        <!-- Statistics Section -->
<div class="tab-pane fade show active" id="statistics" role="tabpanel" aria-labelledby="statistics-tab">
    <h3>Visitor Statistics</h3>
    
    <!-- Canvas for Line Chart -->
    <canvas id="statsChart" width="400" height="200"></canvas>

    <script>
        // Sample data for the chart (You can replace this with data from your PHP backend)
        var totalVisitsData = [<?php echo implode(",", $totalVisitsArray); ?>]; // Assuming you have an array of total visits
        var uniqueVisitorsData = [<?php echo implode(",", $uniqueVisitorsArray); ?>]; // Assuming you have an array of unique visitors

        var ctx = document.getElementById('statsChart').getContext('2d');
        var statsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'], // Example labels for each month
                datasets: [{
                    label: 'Total Visits',
                    data: totalVisitsData,
                    borderColor: 'rgba(75, 192, 192, 1)', // Line color for total visits
                    backgroundColor: 'rgba(75, 192, 192, 0.2)', // Area color for total visits
                    fill: true, // Fill area under the line
                    tension: 0.4
                }, {
                    label: 'Unique Visitors',
                    data: uniqueVisitorsData,
                    borderColor: 'rgba(153, 102, 255, 1)', // Line color for unique visitors
                    backgroundColor: 'rgba(153, 102, 255, 0.2)', // Area color for unique visitors
                    fill: true, // Fill area under the line
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</div>


        <!-- Edit Content Section -->
        <div class="tab-pane fade" id="editContent" role="tabpanel" aria-labelledby="editContent-tab">
            <h3>Edit Front Page Content</h3>
            <form id="editContentForm" action="save_content.php" method="POST">
                <div class="form-group">
                    <label for="aboutContent">About Me</label>
                    <textarea id="aboutContent" name="aboutContent" class="form-control" rows="5"><?php echo htmlspecialchars($content['about'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="skillsContent">Skills</label>
                    <textarea id="skillsContent" name="skillsContent" class="form-control" rows="5"><?php echo htmlspecialchars($content['skills'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="experienceContent">Work Experience</label>
                    <textarea id="experienceContent" name="experienceContent" class="form-control" rows="5"><?php echo htmlspecialchars($content['experience'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="projectsContent">Projects</label>
                    <textarea id="projectsContent" name="projectsContent" class="form-control" rows="5"><?php echo htmlspecialchars($content['projects'] ?? ''); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
        </div>

        <!-- Inbox Section -->
        <div class="tab-pane fade" id="inbox" role="tabpanel" aria-labelledby="inbox-tab">
            <h3>Inbox</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $message) : ?>
                        <?php list($name, $email, $messageText) = explode(': ', $message); ?>
                        <tr>
                            <td><?php echo htmlspecialchars($name); ?></td>
                            <td><?php echo htmlspecialchars($email); ?></td>
                            <td><?php echo htmlspecialchars($messageText); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script>
    CKEDITOR.replace('aboutContent');
    CKEDITOR.replace('skillsContent');
    CKEDITOR.replace('experienceContent');
    CKEDITOR.replace('projectsContent');
</script>

</body>
</html>
