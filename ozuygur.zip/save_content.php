<?php
$servername = "localhost";
$username = "u468298250_ozuygur";
$password = "Mehpi_numur_99";
$dbname = "u468298250_ozuygur";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM content WHERE id=1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $aboutContent = isset($_POST['aboutContent']) ? $_POST['aboutContent'] : $row['about'];
    $skillsContent = isset($_POST['skillsContent']) ? $_POST['skillsContent'] : $row['skills'];
    $experienceContent = isset($_POST['experienceContent']) ? $_POST['experienceContent'] : $row['experience'];
    $projectsContent = isset($_POST['projectsContent']) ? $_POST['projectsContent'] : $row['projects'];

    $updateSql = "UPDATE content SET about='$aboutContent', skills='$skillsContent', experience='$experienceContent', projects='$projectsContent' WHERE id=1";

    if ($conn->query($updateSql) === TRUE) {
        echo "Content updated successfully";
    } else {
        echo "Error updating content: " . $conn->error;
    }
} else {
    echo "No content found to update.";
}

$conn->close();
// Redirect back to the dashboard
header("Location: dashboard.php");
exit();
?>
