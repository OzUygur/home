<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <meta http-equiv="refresh" content="5;url=index.php">
</head>
<body>
    <header>
        <h1>Thank You!</h1>
    </header>
    <section>
        <center>
        <p style = "color:darkgreen">Your message has been submitted successfully!</p>
        </center>
    </section>
</body>
</html>
