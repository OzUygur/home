<?php
$servername = "localhost";
$username = "u468298250_ozuygur";
$password = "Mehpi_numur_99";
$dbname = "u468298250_ozuygur";

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the visitor is new or returning
$visitor_id = isset($_COOKIE['visitor_id']) ? $_COOKIE['visitor_id'] : uniqid();
setcookie('visitor_id', $visitor_id, time() + (86400 * 30), "/"); // Set a cookie that lasts for 30 days

$ip_address = $_SERVER['REMOTE_ADDR'];
$visit_time = date('Y-m-d H:i:s');

// Insert the visitor data into the database
$sql = "INSERT INTO visits (visitor_id, ip_address, visit_time) VALUES ('$visitor_id', '$ip_address', '$visit_time')";
$conn->query($sql);

$conn->close();
?>
